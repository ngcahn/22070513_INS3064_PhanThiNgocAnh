USE university_db;

/*
 * Query 1: List All Students
 * Description: Retrieves every column and every record from the students table.
 * Expected Output: All 5 student records, including their IDs, codes, names,
 *                  email addresses, genders, and department IDs.
 */
SELECT *
FROM students;

/*
 * Expected Output:
 * +----+-------------+------------------+-------------------------+--------+---------------+
 * | id | student_code| full_name        | email                   | gender | department_id |
 * +----+-------------+------------------+-------------------------+--------+---------------+
 * | 1  | SV001       | Nguyen Ngoc Anh   | ngocanh001@student.edu  | Female | 1             |
 * | 2  | SV002       | Tran Minh Duc     | minhduc002@student.edu  | Male   | 2             |
 * | 3  | SV003       | Le Thu Ha         | thuha003@student.edu    | Female | 3             |
 * | 4  | SV004       | Pham Quang Huy    | quanghuy004@student.edu | Male   | 4             |
 * | 5  | SV005       | Doan Mai Linh     | mailinh005@student.edu  | Female | 5             |
 * +----+-------------+------------------+-------------------------+--------+---------------+
 * (5 rows)
 */

/*
 * Query 2: Courses with at Least 3 Credits
 * Description: Uses the comparison operator >= to find courses with 3 or more credits.
 * Expected Output: Five courses, each with 3 credits.
 */
SELECT course_code, course_name, credits
FROM courses
WHERE credits >= 3
ORDER BY id ASC;

/*
 * Expected Output:
 * +-------------+------------------------+---------+
 * | course_code | course_name            | credits |
 * +-------------+------------------------+---------+
 * | MIS301      | Database Management    | 3       |
 * | IT302       | Web Development        | 3       |
 * | FIN303      | Financial Management   | 3       |
 * | ACC304      | Financial Accounting   | 3       |
 * | BUS305      | Business Management    | 3       |
 * +-------------+------------------------+---------+
 * (5 rows)
 */

/*
 * Query 3: Female Students in Department 1
 * Description: Uses AND to require both conditions: department_id must be 1
 *              and gender must be Female.
 * Expected Output: One student, SV001 Nguyen Ngoc Anh.
 */
SELECT student_code, full_name, gender, department_id
FROM students
WHERE department_id = 1
  AND gender = 'Female';

/*
 * Expected Output:
 * +-------------+------------------+--------+---------------+
 * | student_code| full_name        | gender | department_id |
 * +-------------+------------------+--------+---------------+
 * | SV001       | Nguyen Ngoc Anh   | Female | 1             |
 * +-------------+------------------+--------+---------------+
 * (1 row)
 */

/*
 * Query 4: Sort Students by Full Name
 * Description: Sorts student records by full_name in ascending alphabetical order.
 * Expected Output: All 5 students ordered from Doan Mai Linh to Tran Minh Duc.
 */
SELECT student_code, full_name, email
FROM students
ORDER BY full_name ASC;

/*
 * Expected Output:
 * +-------------+------------------+-------------------------+
 * | student_code| full_name        | email                   |
 * +-------------+------------------+-------------------------+
 * | SV005       | Doan Mai Linh     | mailinh005@student.edu  |
 * | SV003       | Le Thu Ha         | thuha003@student.edu    |
 * | SV001       | Nguyen Ngoc Anh   | ngocanh001@student.edu  |
 * | SV004       | Pham Quang Huy    | quanghuy004@student.edu |
 * | SV002       | Tran Minh Duc     | minhduc002@student.edu  |
 * +-------------+------------------+-------------------------+
 * (5 rows)
 */

/*
 * Query 5: Three Highest Enrollment Grades
 * Description: Excludes NULL grades, sorts the remaining grades from highest
 *              to lowest, and returns only the first 3 rows.
 * Expected Output: Three enrollment records with grades 3.90, 3.80, and 3.75.
 */
SELECT student_id, course_id, grade
FROM enrollments
WHERE grade IS NOT NULL
ORDER BY grade DESC
LIMIT 3;

/*
 * Expected Output:
 * +------------+-----------+-------+
 * | student_id | course_id | grade |
 * +------------+-----------+-------+
 * | 5          | 5         | 3.90  |
 * | 3          | 3         | 3.80  |
 * | 1          | 1         | 3.75  |
 * +------------+-----------+-------+
 * (3 rows)
 */

/*
 * Query 6: Find Courses Containing Management
 * Description: Uses LIKE with % wildcards to find course names containing
 *              the word "Management".
 * Expected Output: Three courses: Database Management, Financial Management,
 *                  and Business Management.
 */
SELECT course_code, course_name, credits
FROM courses
WHERE course_name LIKE '%Management%'
ORDER BY id ASC;

/*
 * Expected Output:
 * +-------------+------------------------+---------+
 * | course_code | course_name            | credits |
 * +-------------+------------------------+---------+
 * | MIS301      | Database Management    | 3       |
 * | FIN303      | Financial Management   | 3       |
 * | BUS305      | Business Management    | 3       |
 * +-------------+------------------------+---------+
 * (3 rows)
 */

/*
 * Query 7: Count All Students
 * Description: Uses COUNT(*) to calculate the total number of records in students.
 * Expected Output: One row with total_students equal to 5.
 */
SELECT COUNT(*) AS total_students
FROM students;

/*
 * Expected Output:
 * +----------------+
 * | total_students |
 * +----------------+
 * | 5              |
 * +----------------+
 * (1 row)
 */

/*
 * Query 8: Count Courses in Each Department
 * Description: Joins departments with courses, groups the courses by department,
 *              and uses HAVING to keep only departments with at least one course.
 * Expected Output: Five departments, each with one course.
 */
SELECT
    d.id,
    d.name AS department_name,
    COUNT(c.id) AS total_courses
FROM departments d
LEFT JOIN courses c
    ON d.id = c.department_id
GROUP BY d.id, d.name
HAVING COUNT(c.id) >= 1
ORDER BY d.id ASC;

/*
 * Expected Output:
 * +----+--------------------------------+--------------+
 * | id | department_name                | total_courses|
 * +----+--------------------------------+--------------+
 * | 1  | Management Information Systems  | 1            |
 * | 2  | Information Technology          | 1            |
 * | 3  | Finance                        | 1            |
 * | 4  | Accounting                     | 1            |
 * | 5  | Business Administration        | 1            |
 * +----+--------------------------------+--------------+
 * (5 rows)
 */

/*
 * Query 9: Courses with Instructor Names
 * Description: Joins courses and instructors through instructor_id to show
 *              each course alongside the full name of its instructor.
 * Expected Output: Five courses with their corresponding instructor names.
 */
SELECT
    c.course_code,
    c.course_name,
    i.full_name AS instructor_name
FROM courses c
JOIN instructors i
    ON c.instructor_id = i.id
ORDER BY c.id ASC;

/*
 * Expected Output:
 * +-------------+------------------------+------------------+
 * | course_code | course_name            | instructor_name  |
 * +-------------+------------------------+------------------+
 * | MIS301      | Database Management    | Nguyen Van An    |
 * | IT302       | Web Development        | Tran Thi Lan     |
 * | FIN303      | Financial Management   | Le Quang Minh    |
 * | ACC304      | Financial Accounting   | Pham Thi Hoa     |
 * | BUS305      | Business Management    | Hoang Van Nam    |
 * +-------------+------------------------+------------------+
 * (5 rows)
 */

/*
 * Query 10: Enrollment Details with Student, Course, and Semester
 * Description: Joins enrollments with students, courses, and semesters to show
 *              each enrollment with the student, course, semester, and grade.
 * Expected Output: Ten enrollment records with student codes, student names,
 *                  course names, semester names, and grades.
 */
SELECT
    s.student_code,
    s.full_name AS student_name,
    c.course_name,
    se.semester_name,
    e.grade
FROM enrollments e
JOIN students s
    ON e.student_id = s.id
JOIN courses c
    ON e.course_id = c.id
JOIN semesters se
    ON e.semester_id = se.id
ORDER BY e.id ASC;

/*
 * Expected Output:
 * +-------------+------------------+------------------------+------------------------+-------+
 * | student_code| student_name     | course_name            | semester_name          | grade |
 * +-------------+------------------+------------------------+------------------------+-------+
 * | SV001       | Nguyen Ngoc Anh   | Database Management    | Semester 1 2026-2027   | 3.75  |
 * | SV001       | Nguyen Ngoc Anh   | Web Development        | Semester 1 2026-2027   | 3.50  |
 * | SV002       | Tran Minh Duc     | Web Development        | Semester 1 2026-2027   | 3.25  |
 * | SV002       | Tran Minh Duc     | Financial Management   | Semester 1 2026-2027   | 3.00  |
 * | SV003       | Le Thu Ha         | Financial Management   | Semester 1 2026-2027   | 3.80  |
 * | SV003       | Le Thu Ha         | Financial Accounting   | Semester 1 2026-2027   | 3.60  |
 * | SV004       | Pham Quang Huy    | Financial Accounting   | Semester 1 2026-2027   | 3.40  |
 * | SV004       | Pham Quang Huy    | Business Management   | Semester 1 2026-2027   | 3.20  |
 * | SV005       | Doan Mai Linh     | Database Management    | Semester 1 2026-2027   | 3.70  |
 * | SV005       | Doan Mai Linh     | Business Management   | Semester 1 2026-2027   | 3.90  |
 * +-------------+------------------+------------------------+------------------------+-------+
 * (10 rows)
 */
